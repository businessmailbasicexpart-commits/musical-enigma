package com.myandroidguard.app.service

import android.content.Context
import android.os.BatteryManager
import android.util.Log
import com.myandroidguard.app.api.ApiClient
import com.myandroidguard.app.api.HeartbeatRequest
import com.myandroidguard.app.data.DevicePrefs
import kotlinx.coroutines.delay

class CommandPoller(private val context: Context) {
    private val api = ApiClient.service

    companion object {
        private const val TAG = "CommandPoller"
    }

    suspend fun startPolling() {
        Log.d(TAG, "Polling started")
        while (true) {
            try {
                val token = DevicePrefs.getDeviceToken(context)
                if (token == null) {
                    Log.w(TAG, "No device token, skipping poll")
                    delay(10_000)
                    continue
                }
                Log.d(TAG, "Polling for commands...")
                val response = api.getCommands(token)
                Log.d(TAG, "Got ${response.commands.size} commands")
                for (cmd in response.commands) {
                    Log.d(TAG, "Executing command: ${cmd.type}")
                    CommandHandlers.execute(context, cmd.type, cmd.payload, cmd.id)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Poll error: ${e.message}", e)
            }
            delay(10_000)
        }
    }

    suspend fun sendHeartbeat() {
        try {
            val token = DevicePrefs.getDeviceToken(context) ?: run {
                Log.w(TAG, "No token for heartbeat")
                return
            }
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            api.heartbeat(token, HeartbeatRequest(battery))
            Log.d(TAG, "Heartbeat sent (battery: $battery%)")
        } catch (e: Exception) { Log.e(TAG, "Heartbeat error: ${e.message}") }
    }
}