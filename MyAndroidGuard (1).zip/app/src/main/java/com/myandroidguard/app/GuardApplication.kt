package com.myandroidguard.app

import android.app.Application

class GuardApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}