package com.myandroidguard.app.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Looper
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.myandroidguard.app.api.ApiClient
import com.myandroidguard.app.api.LocationUpdateRequest
import com.myandroidguard.app.data.DevicePrefs
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.Locale

class LocationTracker(private val context: Context) {
    private val fusedClient = LocationServices.getFusedLocationProviderClient(context)
    private val api = ApiClient.service

    fun startTracking() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 60_000)
            .setMinUpdateIntervalMillis(15_000)
            .setWaitForAccurateLocation(true).build()

        fusedClient.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                GlobalScope.launch {
                    try {
                        val token = DevicePrefs.getDeviceToken(context) ?: return@launch
                        val address = try {
                            Geocoder(context, Locale("bn")).getFromLocation(loc.latitude, loc.longitude, 1)
                                ?.firstOrNull()?.let { "${it.subLocality ?: ""}, ${it.locality ?: ""}" }
                        } catch (_: Exception) { null }
                        api.sendLocation(token, LocationUpdateRequest(loc.latitude, loc.longitude, address))
                    } catch (_: Exception) {}
                }
            }
        }, Looper.getMainLooper())
    }
}