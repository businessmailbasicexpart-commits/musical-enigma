package com.myandroidguard.app.service

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

object SilentCameraCapture {
    private const val TAG = "SilentCamera"

    suspend fun capturePhoto(context: Context, useFrontCamera: Boolean = true): File? {
        return suspendCoroutine { cont ->
            try {
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        val imageCapture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()

                        val cameraSelector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA
                            else CameraSelector.DEFAULT_BACK_CAMERA

                        cameraProvider.unbindAll()

                        if (context is LifecycleOwner) {
                            cameraProvider.bindToLifecycle(context, cameraSelector, imageCapture)
                        } else {
                            cont.resume(null)
                            return@addListener
                        }

                        val photoFile = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(context),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                    Log.d(TAG, "Photo captured: ${photoFile.absolutePath}")
                                    cameraProvider.unbindAll()
                                    cont.resume(photoFile)
                                }
                                override fun onError(exc: ImageCaptureException) {
                                    Log.e(TAG, "Capture failed", exc)
                                    cameraProvider.unbindAll()
                                    cont.resume(null)
                                }
                            })
                    } catch (e: Exception) {
                        Log.e(TAG, "Camera bind failed", e)
                        cont.resume(null)
                    }
                }, ContextCompat.getMainExecutor(context))
            } catch (e: Exception) {
                Log.e(TAG, "Camera init failed", e)
                cont.resume(null)
            }
        }
    }
}