package com.myandroidguard.app.service

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.myandroidguard.app.receiver.DeviceAdminReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object CommandHandlers {
    fun execute(context: Context, type: String, payload: Map<String, Any>, commandId: String? = null) {
        when (type) {
            "ring" -> ringDevice(context)
            "lock" -> lockDevice(context)
            "wipe" -> wipeDevice(context)
            "tap" -> {
                val x = (payload["x"] as? Number)?.toFloat() ?: return
                val y = (payload["y"] as? Number)?.toFloat() ?: return
                RemoteControlAccessibilityService.performTap(x, y)
            }
            "swipe" -> {
                val dir = payload["direction"] as? String ?: return
                RemoteControlAccessibilityService.performSwipe(dir)
            }
            "back" -> RemoteControlAccessibilityService.performBack()
            "home" -> RemoteControlAccessibilityService.performHome()
            "recents" -> RemoteControlAccessibilityService.performRecents()
            "locate" -> { /* LocationTracker handles this */ }
            "vibrate" -> vibrateDevice(context)
            "volume_up", "volume_down" -> adjustVolume(context, type)
            "capture_photo" -> {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val useFront = (payload["camera"] as? String) != "back"
                        SilentCameraCapture.capturePhoto(context, useFrontCamera = useFront)
                    } catch (e: Exception) { e.printStackTrace() }
                }
            }
            "screenshot" -> RemoteControlAccessibilityService.takeAndUploadScreenshot()
            "start_screen_share" -> RemoteControlAccessibilityService.startScreenShare()
            "stop_screen_share" -> RemoteControlAccessibilityService.stopScreenShare()
            "refresh_screen" -> RemoteControlAccessibilityService.takeAndUploadScreenshot()
        }
    }

    private fun vibrateDevice(context: Context) {
        if (Build.VERSION.SDK_INT >= 31) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(1000)
            }
        }
    }

    private fun adjustVolume(context: Context, type: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (type == "volume_up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
    }

    private fun ringDevice(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        MediaPlayer.create(context, uri)?.apply { isLooping = true; start() }
    }

    private fun lockDevice(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, DeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) dpm.lockNow()
    }

    private fun wipeDevice(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, DeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) dpm.wipeData(0)
    }
}