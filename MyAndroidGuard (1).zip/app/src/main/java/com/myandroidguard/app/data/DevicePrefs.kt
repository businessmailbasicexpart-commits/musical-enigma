package com.myandroidguard.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "guard_prefs")

object DevicePrefs {
    private val DEVICE_TOKEN = stringPreferencesKey("device_token")
    private val DEVICE_ID = stringPreferencesKey("device_id")
    private val USER_EMAIL = stringPreferencesKey("user_email")

    suspend fun saveDeviceToken(context: Context, token: String) {
        context.dataStore.edit { it[DEVICE_TOKEN] = token }
    }
    suspend fun getDeviceToken(context: Context): String? =
        context.dataStore.data.map { it[DEVICE_TOKEN] }.first()

    suspend fun saveDeviceId(context: Context, id: String) {
        context.dataStore.edit { it[DEVICE_ID] = id }
    }
    suspend fun getDeviceId(context: Context): String? =
        context.dataStore.data.map { it[DEVICE_ID] }.first()

    suspend fun saveUserEmail(context: Context, email: String) {
        context.dataStore.edit { it[USER_EMAIL] = email }
    }
    suspend fun getUserEmail(context: Context): String? =
        context.dataStore.data.map { it[USER_EMAIL] }.first()

    suspend fun isPaired(context: Context): Boolean = getDeviceToken(context) != null
}