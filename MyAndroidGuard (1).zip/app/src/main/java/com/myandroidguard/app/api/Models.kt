package com.myandroidguard.app.api

data class AutoRegisterRequest(
    val user_email: String,
    val device_name: String,
    val model: String,
    val os_version: String,
    val imei_hash: String? = null
)

data class AutoRegisterResponse(
    val device_id: String,
    val device_token: String,
    val message: String,
    val is_new: Boolean
)

data class HeartbeatRequest(
    val battery_level: Int,
    val is_online: Boolean = true
)

data class LocationUpdateRequest(
    val lat: Double,
    val lng: Double,
    val address: String? = null
)

data class CaptureUploadRequest(
    val type: String,
    val location: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val trigger: String = "manual",
    val storage_path: String? = null,
    val metadata: Map<String, Any>? = null
)

data class Command(
    val id: String,
    val type: String,
    val payload: Map<String, Any>,
    val status: String
)

data class CommandsResponse(
    val commands: List<Command>
)

data class ScreenshotUploadRequest(
    val image_base64: String
)