package com.myandroidguard.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.util.Base64
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.myandroidguard.app.api.ApiClient
import com.myandroidguard.app.api.ScreenshotUploadRequest
import com.myandroidguard.app.data.DevicePrefs
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream

class RemoteControlAccessibilityService : AccessibilityService() {
    companion object {
        private const val TAG = "ScreenMirror"
        private var instance: RemoteControlAccessibilityService? = null
        private var screenShareActive = false
        private var screenShareJob: Job? = null

        fun performTap(xPercent: Float, yPercent: Float) {
            val s = instance ?: return
            val dm = s.resources.displayMetrics
            val path = Path().apply { moveTo((xPercent/100f)*dm.widthPixels, (yPercent/100f)*dm.heightPixels) }
            s.dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 100)).build(), null, null)
        }

        fun performSwipe(direction: String) {
            val s = instance ?: return
            val dm = s.resources.displayMetrics
            val cx = dm.widthPixels/2f; val cy = dm.heightPixels/2f; val d = dm.heightPixels/3f
            val path = Path()
            when (direction) {
                "up" -> { path.moveTo(cx, cy+d/2); path.lineTo(cx, cy-d/2) }
                "down" -> { path.moveTo(cx, cy-d/2); path.lineTo(cx, cy+d/2) }
                "left" -> { path.moveTo(cx+d/2, cy); path.lineTo(cx-d/2, cy) }
                "right" -> { path.moveTo(cx-d/2, cy); path.lineTo(cx+d/2, cy) }
            }
            s.dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(), null, null)
        }

        fun performBack() { instance?.performGlobalAction(GLOBAL_ACTION_BACK) }
        fun performHome() { instance?.performGlobalAction(GLOBAL_ACTION_HOME) }
        fun performRecents() { instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) }

        fun takeAndUploadScreenshot() {
            val s = instance ?: run { Log.w(TAG, "Accessibility not connected"); return }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                Log.w(TAG, "Screenshot requires API 30+"); return
            }
            s.takeScreenshot(Display.DEFAULT_DISPLAY,
                s.mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val hwBitmap = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                            if (hwBitmap == null) { Log.e(TAG, "Failed to wrap buffer"); return@launch }
                            val bitmap = hwBitmap.copy(Bitmap.Config.ARGB_8888, false)
                            hwBitmap.recycle()
                            result.hardwareBuffer.close()

                            // Compress to JPEG
                            val stream = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream)
                            bitmap.recycle()
                            val base64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

                            // Upload
                            val token = DevicePrefs.getDeviceToken(s) ?: return@launch
                            ApiClient.service.uploadScreenshot(token, ScreenshotUploadRequest(base64))
                            Log.d(TAG, "Screenshot uploaded (${stream.size()/1024}KB)")
                        } catch (e: Exception) { Log.e(TAG, "Screenshot upload failed", e) }
                    }
                }
                override fun onFailure(errorCode: Int) { Log.e(TAG, "Screenshot failed: $errorCode") }
            })
        }

        fun startScreenShare() {
            screenShareActive = true
            screenShareJob?.cancel()
            screenShareJob = CoroutineScope(Dispatchers.IO).launch {
                while (isActive && screenShareActive) {
                    takeAndUploadScreenshot()
                    delay(2000) // every 2 seconds
                }
            }
            Log.d(TAG, "Screen share started")
        }

        fun stopScreenShare() {
            screenShareActive = false
            screenShareJob?.cancel()
            screenShareJob = null
            Log.d(TAG, "Screen share stopped")
        }
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; stopScreenShare(); super.onDestroy() }
}