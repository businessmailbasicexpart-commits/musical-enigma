# MyAndroid Guard - Android App

## সেটআপ

1. Android Studio তে এই ফোল্ডার ওপেন করুন
2. Gradle sync হতে দিন
3. USB দিয়ে ডিভাইস সংযুক্ত করুন (USB Debugging চালু)
4. Run বাটনে ক্লিক করুন

## সার্ভার URL
https://dujrhpxczaulfcudmwmm.supabase.co/functions/v1/device-api/

## অ্যাপ আচরণ
- ইনস্টলের পর অটো পারমিশন ডায়ালগ আসবে (Allow চাপুন)
- সব পারমিশন দেওয়ার পর অ্যাপ আইকন হাইড হবে
- ব্যাকগ্রাউন্ড সার্ভিস অটো চালু থাকবে
- ফোন রিস্টার্টেও সার্ভিস অটো চালু হবে

## Min SDK: Android 7.0 (API 24)
## Target SDK: Android 15 (API 35)
